import os
from shutil import copyfile
def read_txt_file(file_path):
    # 检查文件是否存在
    if os.path.isfile(file_path) and file_path.endswith('.txt'):
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    else:
        print(f'文件路径无效或不是txt文件: {file_path}')
    return content
# 指定文件路径
file_path =""
# 调用函数读取txt文件内容
val_line = read_txt_file(file_path)
lines = val_line.strip().split('\n')
image_paths = [line.split(' ')[0] for line in lines]
# 定义图像保存的目标文件夹
target_folder =""

# 创建目标文件夹（如果不存在）
os.makedirs(target_folder, exist_ok=True)

# 遍历图像路径并拷贝图像到目标文件夹
for path in image_paths:
    image_path = path.strip()
    image_name = os.path.basename(image_path)
    target_path = os.path.join(target_folder, image_name)

    # 拷贝图像到目标文件夹
    try:
        copyfile(image_path, target_path)
        print(f"Image {image_name} copied to {target_folder}")
    except FileNotFoundError:
        print(f"Image {image_name} not found.")
    except Exception as e:
        print(f"Error copying {image_name}: {e}")