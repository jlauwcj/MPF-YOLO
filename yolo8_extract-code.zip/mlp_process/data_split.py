import numpy as np
import pandas as pd
def split_data(data):
    df = pd.DataFrame(columns=['lat', 'lon'])

    # 循环处理每行数据
    if not isinstance(data, list):
        data = [data]
    for line in data:
        parts = line.split(".jpg")[0].split('/')[-1].split('_')
        latitude = float(parts[0])
        longitude = float(parts[1])
        # 将提取的数据添加到DataFrame
        df = pd.concat([df,pd.DataFrame({'lat':[latitude], 'lon' : [longitude]})],ignore_index=True)

    # 打印结果
    return df
