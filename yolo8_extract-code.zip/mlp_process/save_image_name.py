import pandas as pd
import os
def save_name(csv_data) :
    df = csv_data

    # 获取第一行数据
    row = df.iloc[0]

    # 获取第一行数据
    row = df.iloc[0]

    # 将经纬度合并成image_name
    image_name = f"{row['lat']}_{row['lon']}"

    # 指定文件夹路径
    output_folder =

    # 确保文件夹存在，如果不存在则创建
    os.makedirs(output_folder, exist_ok=True)

    # 构造txt文件名，包含文件夹路径
    txt_file_path = os.path.join(output_folder, "image_name.txt")

    # 将image_name保存到txt文件
    with open(txt_file_path, 'w') as file:
        file.write(image_name)

